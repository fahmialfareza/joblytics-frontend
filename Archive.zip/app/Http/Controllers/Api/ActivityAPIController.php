<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

class ActivityAPIController extends Controller
{
    //
}
